const app = require("./src/server");

app.listen(3000, () => {
  console.log("http://localhost:3000");
});
